
const mensajeBien =document.getElementById("mensaje-bien")
const nombre = prompt ("¡Hola! ¿Cual es tu nombre?")
const botonSeries =document.getElementById("series")
const botonPeliculas =document.getElementById("peliculas")
const seccionUno = document.getElementById ("preguntasSeries")
const seccionDos = document.getElementById ("preguntasPeliculas")

mensajeBien.innerHTML= "Hola " + nombre + " ¿Con qué quieres empezar?"

const preguntasSeries = () => {
seccionUno.classList.remove("aparecer")
}

const preguntasPeliculas = () => {
seccionDos.classList.remove("aparecer")
}


botonPeliculas.addEventListener("click", preguntasPeliculas)
botonSeries.addEventListener("click", preguntasSeries)